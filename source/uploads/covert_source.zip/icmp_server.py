# Copyright 2011 Jake Valletta
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import sys, re, argparse, logging
logging.getLogger("scapy.runtime").setLevel(logging.ERROR) #Supress SCAPY Warnings
from scapy.all import *
from pyDes import *

########From Hex#
def print_covert(inint):
	return_string=''
        hex_string = hex(inint) 		#covert to hex
        hex_string = hex_string[2:]		#crop off the '0x'
	while len( hex_string )!=0:
 	        if len(hex_string)%2==1: hex_string = '0'+hex_string
		sys.stdout.write(chr( int(hex_string[0:2], 16) ))
		sys.stdout.flush()
		hex_string = hex_string[2:]

###########Read Packet#
def read_packet(inpkt):
	global field
	global source
	global ipv4
	payload_key = "$3Cr371!" 

	if field=='ip_id': print_covert(inpkt['IP'].id if (ipv4) else int(inpkt['IPv6'].fl))
	elif field=='ip_tos': print_covert(inpkt['IP'].tos if (ipv4) else int(inpkt['IPv6'].tc))
	elif field=='icmp_code': print_covert(inpkt['ICMP'].code if (ipv4) else inpkt['ICMPv6 Echo Request'].code)
	elif field=='icmp_id': print_covert(inpkt['ICMP'].id if (ipv4) else inpkt['ICMPv6 Echo Request'].id)
	elif field=='icmp_seq': print_covert(inpkt['ICMP'].seq if (ipv4) else inpkt['ICMPv6 Echo Request'].seq)
	elif field=='payload': 
		des_key = des( payload_key, CBC, "\0\0\0\0\0\0\0\0", pad=None, padmode=PAD_PKCS5)
		sys.stdout.write(des_key.decrypt(inpkt.load if (ipv4) else inpkt['ICMPv6 Echo Request'].data))

#############Main##
ipv4=1
ipv6=0

parser = argparse.ArgumentParser(prog=sys.argv[0])
parser.add_argument('-s', metavar='<source>', dest='source',  help='Only listen for a specific address..')
parser.add_argument('-4', metavar='', dest='4', action='store_const', const="on", default="on", help='Use IP/ICMPv4.')
parser.add_argument('-6', metavar='', dest='6', action='store_const', const="on", default="off", help='Use IP/ICMPv6.')
parser.add_argument('-f', metavar='<field>', required="yes", dest='field', choices=['ip_id', 'ip_tos', 'icmp_code', 'icmp_seq', 'icmp_id', 'payload'],
							default='payload',help="Which field to listen. [ip_id, ip_tos, icmp_code, icmp_seq, icmp_id, payload]")
args = parser.parse_args()
source = args.__dict__['source']
field = args.__dict__['field']

if args.__dict__['6'] == "on": 
	ipv4=0
	ipv6=1	

sniff(lfilter=lambda x: (x.haslayer(ICMP) and x['ICMP'].type ==8) if (ipv4) else (x.haslayer(ICMPv6EchoRequest) and x['ICMPv6 Echo Request'].type == 128),  count=0, store=0, prn=read_packet)
