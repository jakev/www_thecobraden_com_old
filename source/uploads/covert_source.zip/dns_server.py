# Copyright 2011 Jake Valletta
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import time, socket, re, os, logging
logging.getLogger("scapy.runtime").setLevel(logging.ERROR) #Supress Scapy Warnings
from scapy.all import *

maps = {
		'a' : 'z',
		'b' : 'y',
		'c' : 'x',
		'd' : 'w',
		'e' : 'v',
		'f' : 'u',
		'g' : 't',
		'h' : 's',
		'i' : 'r',
		'j' : 'q',
		'k' : 'p',
		'l' : 'o',
		'm' : 'n',
		'n' : 'm',
		'o' : 'l',
		'p' : 'k',
		'q' : 'j',
		'r' : 'i',
		's' : 'h',
		't' : 'g',
		'u' : 'f',
		'v' : 'e',
		'w' : 'd',
		'x' : 'c',
		'y' : 'b',
		'z' : 'a' }

def recieved(pkt):
	print "[INCOMING DNS REQUEST] ",
	inqry = re.sub("\.", " ", pkt['DNS'].qd.qname)
	inqry = re.sub("\scom\s$", "", inqry)
	print unmap(inqry)

def unmap(query):
	global maps
	unmapped=''
	for i in query:
		if i in [ '1','2','3','4','5','6','7','8,','9','0']:
			unmapped+=i
			continue
		if i == ' ': 
			unmapped+=" "
			continue
		unmapped+=maps[i]
	return unmapped


##Main
os.system('clear')
serversocket = socket.socket( socket.AF_INET, socket.SOCK_DGRAM )
serversocket.bind(('', 53))
print "Socket Created, listening!"
sniff(lfilter=lambda x: x.haslayer(DNS), count=0, prn=recieved)
