# Copyright 2011 Jake Valletta
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import sys, time, argparse, re, logging
logging.getLogger("scapy.runtime").setLevel(logging.ERROR) #Supress Scapy Warnings
from scapy.all import *

DOMAIN_LENGTH = 8			#domain length maximum
maps = {
		'a' : 'z',
		'b' : 'y',
		'c' : 'x',
		'd' : 'w',
		'e' : 'v',
		'f' : 'u',
		'g' : 't',
		'h' : 's',
		'i' : 'r',
		'j' : 'q',
		'k' : 'p',
		'l' : 'o',
		'm' : 'n',
		'n' : 'm',
		'o' : 'l',
		'p' : 'k',
		'q' : 'j',
		'r' : 'i',
		's' : 'h',
		't' : 'g',
		'u' : 'f',
		'v' : 'e',
		'w' : 'd',
		'x' : 'c',
		'y' : 'b',
		'z' : 'a' }

def scrub(inp):	
	inp = re.sub("\s+$", '', inp)
	inp = re.sub("^\s+", '', inp)
	inp = re.sub("[^a-zA-Z0-9 ]",'', inp)
	inp = inp.lower()
	inp = re.sub("\s+", " ", inp)
	return inp
	
def reverse(s):
	new=''
	for char in s:
		if char in [ '1','2','3','4','5','6','7','8,','9','0']:
			new+=char
			continue
		if char == ' ':
			new+=' '
			continue
		new+=maps[char]
	return new

def toSections(s, count):
	message=''
	size = re.sub(" ","",s)
	words = re.split(" ", s)
	for word in words:
		if len(word) > count-1:
			while len(word) > 0:
				message+=word[0:count]+'.'				
				word = word[count:]
		else: message+=word+'.'
	 	 
	message+="com"
	message = re.sub("\.\.","\.", message)	
	return message

def sendPacket(s):
	#id, sport, dns_id
	packet = IP(dst=destination)/UDP(dport=53, sport=4263)/DNS(id = 16, qr=0, ra=1, rd=1, z=8, qdcount=1, qd=DNSRR(rrname=s, ttl=330, type="A") )
	send(packet, verbose=0)

##Main	
parser = argparse.ArgumentParser(prog=sys.argv[0])
parser.add_argument('-d', '--destination', nargs='?', required=True, help='Enter one or more destinations to send the message to via ICMP')
parser.add_argument('-s', '--source', nargs='?', help='Spoof the source address if your recpt knows your address')
args = parser.parse_args()

destination = args.__dict__['destination']
source = args.__dict__['source']

socket = socket.socket( socket.AF_INET, socket.SOCK_DGRAM )
socket.bind(('', 4263))				#open an emphemeral

while 1:
	text = raw_input("\nEnter text to send: ")
	if text =='q': break
	print text+"===> ",
	text = scrub(text)
	text = reverse(text)
	sections = toSections(text, int(DOMAIN_LENGTH) )
	print sections
	sendPacket(sections)
	
socket.close()